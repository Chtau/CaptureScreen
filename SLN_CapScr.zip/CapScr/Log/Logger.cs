﻿using System;
using System.IO;

namespace CapScr.Log
{
    public static class Logger
    {
        private static string mLogFullFileName = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\CapScr.log";

        public static void Log(string Text, Exception ex)
        {
            if (ex != null)
            {
                OnLog(Text + "Error:" + ex.Message);
            }
        }

        public static void Log(Exception ex)
        {
            if (ex != null)
            {
                OnLog(ex.Message);
            }
        }

        public static void Log(string strText)
        {
            OnLog(strText);
        }

        public static void Log(string strText, string strLogFile)
        {
            OnLog(strText, strLogFile);
        }

        private static void OnLog(string strText, string strLogFile)
        {
            if (!OnWriteToFile(strText, strLogFile))
            {
                System.Diagnostics.Debug.Print(string.Format("Can't write to Log File, Text:'{0}' File:'{1}'", strText, strLogFile));
            }
        }

        private static void OnLog(string strText)
        {
            OnLog(strText, mLogFullFileName);
        }

        private static bool OnWriteToFile(string strText, string strFile)
        {
            if (!string.IsNullOrEmpty(strText) && !string.IsNullOrEmpty(strFile))
            {
                string strDirectory = Path.GetDirectoryName(strFile);
                if (!string.IsNullOrEmpty(strDirectory))
                {
                    if (Global.Helper.CheckDirectoryAccess(strDirectory))
                    {
                        try
                        {
                            File.AppendAllText(strFile, strText + "\r\n");
                            return true;
                        } catch (Exception ex)
                        {
                            System.Diagnostics.Debug.Print(string.Format("Unexpected Error while writing Log File, File:'{0}' Text:'{1}' Error:'{2}'",strFile, strText, ex.Message));
                        }
                    }
                }
            }
            return false;
        }

    }
}
